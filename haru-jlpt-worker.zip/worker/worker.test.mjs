import test from 'node:test';
import assert from 'node:assert/strict';
import worker,{handleRequest,AnalysisQuota} from './worker.mjs';
const ORIGIN='https://tuski0.github.io',TOKEN='test-only-connection-password-32chars';
const text='私は日本語を勉強しています。';
const answer={kind:'sentence',reading:'わたしはにほんごをべんきょうしています。',meaning:'저는 일본어를 공부하고 있습니다。',segments:[{text:'私は',reading:'わたしは',meaning:'나는',role:'화제',explanation:'は는 이야기의 주제를 표시해요.'},{text:'日本語を',reading:'にほんごを',meaning:'일본어를',role:'목적어',explanation:'を는 공부하는 대상을 표시해요.'},{text:'勉強しています。',reading:'べんきょうしています。',meaning:'공부하고 있습니다.',role:'서술어',explanation:'공부하는 중임을 나타내요.'}],grammar:[{pattern:'〜ています',explanation:'진행 중인 동작을 나타낼 수 있어요.'}],examples:[],kanjiMeanings:[{character:'私',meaning:'나, 사사로울'}],notes:[]};
function ctxFor(map=new Map()) {let tail=Promise.resolve();return {storage:{async get(k){return structuredClone(map.get(k));},async put(k,v){map.set(k,structuredClone(v));}},blockConcurrencyWhile(fn){const next=tail.then(fn);tail=next.catch(()=>{});return next;}};}
function environment(extra={}){const env={GEMINI_API_KEY:'test-only-gemini-key',ANALYSIS_TOKEN:TOKEN,ALLOWED_ORIGINS:ORIGIN,REQUESTS_PER_MINUTE:'30',REQUESTS_PER_DAY:'100',...extra};const quota=new AnalysisQuota(ctxFor(),env);env.ANALYSIS_QUOTA={idFromName:n=>n,get:()=>quota};return env;}
const request=(body={text},headers={},path='/analyze',method='POST')=>new Request('https://unit.example'+path,{method,headers:{Origin:ORIGIN,Authorization:'Bearer '+TOKEN,'Content-Type':'application/json',...headers},...(method==='POST'?{body:JSON.stringify(body)}:{})});
const success=async()=>Response.json({candidates:[{finishReason:'STOP',content:{parts:[{text:JSON.stringify(answer)}]}}]});
test('valid analysis is returned; fixed model/schema and server-only key are used',async()=>{
 let calls=0;const r=await handleRequest(request(),environment(),async(url,init)=>{calls++;assert.equal(url,'https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash-lite:generateContent');assert.equal(init.headers['x-goog-api-key'],'test-only-gemini-key');const body=JSON.parse(init.body);assert.deepEqual(body.contents,[{role:'user',parts:[{text}]}]);assert.ok(body.generationConfig.responseFormat.text.schema.properties.segments);assert.equal(body.generationConfig.maxOutputTokens,6144);return success();});
 assert.equal(r.status,200);assert.deepEqual((await r.json()).analysis,answer);assert.equal(calls,1);assert.equal(r.headers.get('Access-Control-Allow-Origin'),ORIGIN);assert.equal(r.headers.get('Cache-Control'),'no-store');
});
test('unauthorized origins and missing/wrong auth never call Gemini or reserve quota',async()=>{
 const env=environment();let count=0;env.ANALYSIS_QUOTA.get=()=>({fetch(){count++;throw Error();}});
 for(const [headers,status] of [[{Origin:'https://other.example'},403],[{Authorization:''},401],[{Authorization:'Bearer wrong'},401]]){const r=await handleRequest(request({},headers),env,async()=>{count++;throw Error();});assert.equal(r.status,status);if(status===403)assert.equal(r.headers.get('Access-Control-Allow-Origin'),null);}
 assert.equal(count,0);
});
test('deployment without secrets/quota fails closed',async()=>{for(const key of ['GEMINI_API_KEY','ANALYSIS_TOKEN','ANALYSIS_QUOTA']){const env=environment();delete env[key];assert.equal((await handleRequest(request(),env)).status,503);}});
test('health and CORS preflight work without consuming analysis allowance',async()=>{
 const env=environment();env.ANALYSIS_QUOTA.get=()=>{throw Error('must not reserve');};
 const health=await worker.fetch(request(null,{},'/health','GET'),env,{waitUntil(){}});assert.equal(health.status,200);const body=await health.json();assert.equal(body.ok,true);assert.equal(body.maxCharacters,200);assert.ok(!JSON.stringify(body).includes(TOKEN));
 const preflight=await handleRequest(request(null,{Authorization:''},'/analyze','OPTIONS'),{});assert.equal(preflight.status,204);assert.ok(preflight.headers.get('Access-Control-Allow-Headers').includes('Authorization'));
});
test('bounded input, malformed JSON, and non-Japanese are rejected without model calls',async()=>{
 let calls=0;const fetcher=async()=>{calls++;return success();};for(const body of [{text:''},{text:'a plain English text'},{text:'日'.repeat(201)},{text:42},{model:'arbitrary-model'}])assert.equal((await handleRequest(request(body),environment(),fetcher)).status,400);
 const invalid=new Request('https://unit.example/analyze',{method:'POST',headers:{Origin:ORIGIN,Authorization:'Bearer '+TOKEN,'Content-Type':'application/json'},body:'{'});assert.equal((await handleRequest(invalid,environment(),fetcher)).status,400);
 const long=new Request('https://unit.example/analyze',{method:'POST',headers:{Origin:ORIGIN,Authorization:'Bearer '+TOKEN,'Content-Type':'application/json'},body:'a'.repeat(5000)});assert.equal((await handleRequest(long,environment(),fetcher)).status,413);assert.equal(calls,0);
});
test('concurrent requests obey one persistent global quota and denied requests do not call Gemini',async()=>{
 const env=environment({REQUESTS_PER_MINUTE:'5'});let calls=0;
 const replies=await Promise.all(Array.from({length:20},()=>handleRequest(request(),env,async()=>{calls++;return success();})));
 assert.equal(replies.filter(r=>r.status===200).length,5);assert.equal(replies.filter(r=>r.status===429).length,15);assert.equal(calls,5);assert.ok(Number(replies.find(r=>r.status===429).headers.get('Retry-After'))>0);
});
test('daily counter persists on restart, resets at midnight Korea time',async()=>{
 const original=Date.now,map=new Map(),env={REQUESTS_PER_MINUTE:'5',REQUESTS_PER_DAY:'1'};try{
 Date.now=()=>Date.parse('2026-10-07T14:59:00Z');const a=new AnalysisQuota(ctxFor(map),env);const reserve=()=>new Request('https://quota.internal/reserve',{method:'POST'});
 assert.equal((await a.fetch(reserve())).status,200);Date.now=()=>Date.parse('2026-10-07T14:59:59Z');const restarted=new AnalysisQuota(ctxFor(map),env);assert.equal((await restarted.fetch(reserve())).status,429);Date.now=()=>Date.parse('2026-10-07T15:00:00Z');assert.equal((await restarted.fetch(reserve())).status,200);
 assert.deepEqual([...map.keys()],['counter']);assert.ok(!JSON.stringify([...map.values()]).includes(text));
 }finally{Date.now=original;}
});
test('model failures do not expose API keys, tokens or upstream details',async()=>{
 for(const status of [400,401,403,404,429,500]){const r=await handleRequest(request(),environment(),async()=>new Response(TOKEN+' '+text,{status}));assert.equal(r.status,status===429?429:502);const content=await r.text();assert.ok(!content.includes(TOKEN));assert.ok(!content.includes('test-only-gemini-key'));assert.ok(!content.includes(text));}
 const r=await handleRequest(request(),environment(),async()=>{throw new DOMException('timeout','AbortError');});assert.equal(r.status,504);
});
test('truncation, unsafe/invalid shape and wrong source text are rejected',async()=>{
 for(const raw of [{...answer,segments:[]},{...answer,segments:[{...answer.segments[0],text:'다른 문장'}]},{...answer,kanjiMeanings:[{character:'龘',meaning:'not in source'}]},{...answer,grammar:[{pattern:'x',explanation:42}]}]){const r=await handleRequest(request(),environment(),async()=>Response.json({candidates:[{finishReason:'STOP',content:{parts:[{text:JSON.stringify(raw)}]}}]}));assert.equal(r.status,502);}
 const truncated=await handleRequest(request(),environment(),async()=>Response.json({candidates:[{finishReason:'MAX_TOKENS',content:{parts:[{text:JSON.stringify(answer)}]}}]}));assert.equal(truncated.status,502);
});
